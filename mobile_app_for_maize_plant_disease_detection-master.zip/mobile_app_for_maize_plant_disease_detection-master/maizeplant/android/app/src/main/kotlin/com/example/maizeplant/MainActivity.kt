package com.example.maizeplant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
